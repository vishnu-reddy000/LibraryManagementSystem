const form = document.querySelector("form");

form.addEventListener("submit", (e) => {

    const pass = document.querySelector('input[name="password"]').value;

    const confirm = document.querySelector('input[name="confirmPassword"]').value;

    if (pass !== confirm) {

        e.preventDefault();

        alert("Passwords do not match.");

    }

});