package com.library.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

	@PostMapping("/login")
	public String login() {
		return "redirect:/admin";
	}

	@GetMapping("/signup")
	public String signup() {
		return "signup";
	}

	@PostMapping("/signup")
	public String signupSubmit() {
		return "login";
	}

	@GetMapping("/auth/user") // Changed from "/user" to "/auth/user"
	public String user() {
		return "user";
	}
}